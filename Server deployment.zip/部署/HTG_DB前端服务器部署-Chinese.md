# 前端部署

前端服务器地址: 10.203.99.80
git地址: [ZJUEarthData/High-T-Geochemistry-Front-end](https://github.com/ZJUEarthData/High-T-Geochemistry-Front-end.git)

## 1.安装依赖库

``` npm install ```

## 2.生成build文件

``` npm run build ```

生成的dist文件夹位于 /build文件夹下

![前端部署1](前端部署1.png)

## 3.配置服务器环境

(1)连接rvpn

(2)通过ssh命令进入到服务器中

![前端部署2](前端部署2.png)

## 4.配置Nginx

Nginx 作为代理服务器，能够将前端的请求转发给后端，并接受来自后端的返回

(1)使用 ``` apt-get install nginx ``` 命令,安装nginx

![前端部署3](前端部署3.png)

(2)等待其安装依赖库以及Nginx本体

(3)更改 /etc/nginx中的 nginx.conf 为项目build文件夹中的nginx.conf文件

(4)保存

![前端部署4](前端部署4.png)

## 5.配置Build文件

(1)进入到usr/share/nginx/build/文件夹中

(2)将之前build好的dist文件夹放入其中

![前端部署5](前端部署5.png)

## 6.运行Nginx服务器

(1)使用```  nginx -t  ```命令检查nginx.conf的语法是否正确

![前端部署6](前端部署6.png)

(2)使用``` systemctl start nginx ``` 启动nginx服务器
如果已经启动，可用``` systemctl reload nginx ```来重启动

![前端部署7](前端部署7.png)

(3)使用``` systemctl status nginx ```检查nginx服务器

如果有usr/sbin/nginx的字样即代表正常运行

![前端部署8](前端部署8.png)

## 7.检查80端口是否正常挂载

(1)运行``` netstat -anp |grep :80 ```查看80端口运行情况，如果0.0.0.0.0:80对应为Nginx则服务正常

![前端部署9](前端部署9.png)

(2)登录10.203.99.80:80查看前端服务是否正常启动

注：如果依然不行请用```systemctl stop firewalld```关闭防火墙