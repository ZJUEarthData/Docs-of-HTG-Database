# 后端部署

git地址：[ZJUEarthData/High-T-Geochemistry-Database](https://github.com/ZJUEarthData/High-T-Geochemistry-Database)

## 1.切换release分支

（1）从git上拉取代码

（2）```git checkout release``` 选择切换分支

![后端部署1](后端部署1.png)

## 2.拉取最新版本

```git pull origin release```

![后端部署7](后端部署7.png)

## 3.更新配置文件

换为需要更换的数据库主机ip、用户名、密码

![后端部署2](后端部署2.png)

## 4.构建jar包

（1）构建在服务器上运行的后端代码```mvn clean package```

（2）target目录下确认生成

（3）使用``` java -jar HTG_DB-1.0.0-SNAPSHOT.jar ```在本地试运行

（4）在本地测试后端程序是否部署完成

![后端部署3](后端部署3.png)

## 5.配置服务器环境

(1)连接rvpn

(2)通过ssh命令进入到服务器中

![后端部署4](后端部署4.png)

（3）使用```java -version```检查是否安装Java以及Java版本是否为1.8

![后端部署5](后端部署5.png)

如果没有，安装Java8

```
sudo apt update
sudo apt install openjdk-8-jre-headless
```

## 6.上传Jar包

（1）使用XFTP连接服务器

（2）在指定路径下传入jar包（目前路径为/opt/app/）

![后端部署6](后端部署6.png)

## 7.运行jar包

```
java -jar xxx.jar
```

以上图为例，运行

```
java -jar HTG_DB-1.0.0-SNAPSHOT.jar
```

